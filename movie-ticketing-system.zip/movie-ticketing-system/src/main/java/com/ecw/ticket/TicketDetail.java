package com.ecw.ticket;

import com.ecw.show.Show;

public class TicketDetail {
	private int quantity;
	private Show show;
	
	public TicketDetail(int quantity, Show show) {
		this.quantity = quantity;
		this.show = show;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Show getShow() {
		return show;
	}
	public void setShow(Show show) {
		this.show = show;
	}
	
}
