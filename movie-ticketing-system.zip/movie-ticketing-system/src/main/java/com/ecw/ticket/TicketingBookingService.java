package com.ecw.ticket;

public class TicketingBookingService {

	public boolean bookTicket(TicketDetail ticket) {
		int ticketsBooked = ticket.getShow().getTicketsBooked();
		if((ticketsBooked + ticket.getQuantity()) <=30) {
			ticket.getShow().bookTickets(ticket.getQuantity());
			return true;
		}
		return false;
	}
}
