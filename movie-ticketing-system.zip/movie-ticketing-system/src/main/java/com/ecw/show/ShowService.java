package com.ecw.show;

public class ShowService {

	private ShowRepository showRepository;
	
	public void getShows() {
		System.out.println("There are "+ showRepository.getShows().size() + " shows Today:");
		for(Show s:showRepository.getShows()) {
			System.out.println(s.getName() + " ==> " + s.getPrice() + " INR");
		}
	}
	
	public boolean canShowBeCompleted(Show s) {
		if(s.getTicketsBooked() >= 10) {
			return true;
		}
		return false;
	}
	
	public void addShow(Show s) {
		showRepository.addShow(s);
	}
}
