package com.ecw.show;

public class Show {
	private int id;
	private int price;
	private String name;
	private int ticketsBooked;
	
	public Show(int id, int price, String name) {
		this.id = id;
		this.price = price;
		this.name = name;
		this.ticketsBooked = 0;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTicketsBooked() {
		return ticketsBooked;
	}
	public void bookTickets(int quantity) {
		ticketsBooked = ticketsBooked + quantity;
	}
	public int getCollection() {
		return price*ticketsBooked;
	}
	
}
