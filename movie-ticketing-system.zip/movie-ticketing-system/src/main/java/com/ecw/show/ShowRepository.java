package com.ecw.show;

import java.util.ArrayList;
import java.util.List;

public class ShowRepository {

	private List<Show> shows = new ArrayList<>();

	public List<Show> getShows() {
		return shows;
	}
	
	public void addShow(Show s) {
		shows.add(s);
	}
}
