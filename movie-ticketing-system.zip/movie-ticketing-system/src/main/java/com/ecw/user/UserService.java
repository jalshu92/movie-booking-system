package com.ecw.user;

public class UserService {

	private UserRepository userRepository;
	
	public void register(User u) {
		userRepository.addUser(u);
	}
}
