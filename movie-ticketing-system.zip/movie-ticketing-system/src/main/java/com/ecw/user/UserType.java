package com.ecw.user;

public enum UserType {
	CUSTOMER, ADMIN;
}
