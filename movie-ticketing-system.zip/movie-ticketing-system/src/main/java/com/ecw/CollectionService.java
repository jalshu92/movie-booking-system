package com.ecw;

import java.util.List;

import com.ecw.show.Show;
import com.ecw.show.ShowRepository;

public class CollectionService {

	private ShowRepository showRepository;
	
	public int getCollectionByShow(Show s) {
		return s.getCollection();
	}
	
	public int getAllCollection() {
		int sum = 0;
		for(Show s:showRepository.getShows()) {
			sum=sum+s.getCollection();
			System.out.println("Show Id: " + s.getId() + " has Collected  " + s.getCollection() + " INR");
		}
		return sum;
	}
	
	public float getAverageCollection() {
		int sum = 0;
		List<Show> shows = showRepository.getShows();
		for(Show s:shows) {
			sum=sum+s.getCollection();			
		}
		return (float)sum/shows.size();
	}
}
